<?php
/*
برنامه نویس 
@GoldDev
کپی با ذکر منبع
*/
include 'base.php';
if($msg or $photo){
$id = $message_id - 1;
$user["last_msg"] = $id;
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
}
if(!file_exists("data/$from_id")) {
$myfile2 = fopen("ID", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
$user["step"] = "";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
}
if($msg == "/start" or $msg == "/cancel"){
$user["step"] = "";
$user["editation"] = "";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"سلام $first_name

به ربات تلگرامی «🎼آدیو ادیت🎼 » خوش آمدید . 

✅ تو سه سوت کل رباتو برات توضیح میدم خوب بخون بیزحمت ❤️👇

این ربات چه کار هایی میکنه ؟ 

👈 تبدیل لینک به موزیک و برعکس

👈 ادیت کامل موزیک (کاور , آرتیست , سال تولید و ...)

👌 تبدیل موزیک به ویس و برعکس

و خیلی چیزای دیگه⚡️


🎧برای شروع یک آهنگ برام ارسال کن🎧",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]);
}
if($data == "edit-simple"){
GoldDev('deletemessage',[
 'chat_id' => $chatid,
 'message_id' =>$messageid,
]);
$hash_database = json_decode(file_get_contents("hash/$hash_data"),true);
$music_id = $hash_database["music_id"];
$get = GoldDev('getfile',['file_id'=>$music_id]);
$patch = $get->result->file_path;
$music = "https://api.telegram.org/file/GoldDev$Token/$patch";
$user_data["step"] = "edit-music-1";
$user_data["editation"]["url"] = "$music";
$outjson = json_encode($user_data,true);
file_put_contents("data/$chatid",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chatid,
 'text'=>"خب برای ویرایش اول نام خواننده رو ارسال کنید❕
برای لغو عملیات دستور /cancel را ارسال کنید.",
 'parse_mode'=>"HTML",
]); 
}
if($step == "edit-music-1" and $msg !== "/cancel"){
if($msg){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$user["step"] = "edit-music-2";
$user["editation"]["name-khanande"] = "$msg";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"نام خواننده آهنگ شما با موفقیت در سرور ذخیره شد✅
لطفا موضوع (کپشن) آهنگ رو ارسال کنید :",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}else{
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"نام خواننده فقط باید بصورت متن باشد❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]);
}
}
if($step == "edit-music-2" and $msg !== "/cancel"){
if($msg){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$user["step"] = "";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اطلاعات با موفقیت در سرور پردازش شد✔️
در حال آپلود آهنگ شما در تلگرام ...",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
$rand = rand(000,999);
$user_for_music_edit = json_decode(file_get_contents("data/$from_id"),true);
$music_url = $user_for_music_edit["editation"]["url"];
$name_khanande = $user_for_music_edit["editation"]["name-khanande"];
file_put_contents("temp/$rand.mp3",file_get_contents($music_url));
GoldDev('sendaudio',[
'chat_id'=>$chat_id,
'audio'=>new CURLFile("temp/$rand.mp3"),
'title'=>$msg,
'performer'=>$name_khanande,
'caption'=>"آهنگ شما با موفقیت ویرایش شد✔️",
]);
unlink("temp/$rand.mp3");
$user["step"] = "";
$user["editation"] = "";
$outjson9 = json_encode($user,true);
file_put_contents("data/$from_id",$outjson9);
}else{
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"نام خواننده  فقط باید بصورت متن باشد❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"/cancel"]],
],
"resize_keyboard"=>true,
])
]);
}
}
/*
برنامه نویس 
@GoldDev
کپی با ذکر منبع
*/
if($data == "edit-pro"){
GoldDev('deletemessage',[
 'chat_id' => $chatid,
 'message_id' =>$messageid,
]);
$hash_database = json_decode(file_get_contents("hash/$hash_data"),true);
$music_id = $hash_database["music_id"];
$get = GoldDev('getfile',['file_id'=>$music_id]);
$patch = $get->result->file_path;
$music = "https://api.telegram.org/file/GoldDev$Token/$patch";
$user_data["step"] = "edit-music-part-2";
$user_data["editation"]["url"] = "$music";
$outjson = json_encode($user_data,true);
file_put_contents("data/$chatid",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chatid,
 'text'=>"ابتدا عکس (کاور) آهنگ مربوطه را ارسال کنید :",
 'parse_mode'=>"HTML",
]); 
}
if($step == "edit-music-part-2" and $msg !== "/cancel"){
if($photo){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$file_id = $photo[count($photo)-1]->file_id;
$get = GoldDev('getfile',['file_id'=>$file_id]);
$patch = $get->result->file_path;
$cover = "https://api.telegram.org/file/GoldDev$Token/$patch";
$user["step"] = "edit-music-part-3";
$user["editation"]["cover"] = "$cover";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کاور (عکس) آهنگ شما با موفقیت دانلود و در سرور ذخیره شد✅
لطفا نام فایل آهنگ رو ارسال کنید :
مثلا :
<b>Music Name</b>",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}else{
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"لطفا فقط یک عکس ارسال کنید❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]);
}
}
if($step == "edit-music-part-3" and $msg !== "/cancel"){
if($msg){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$rand = rand(000000,999999);
$msg = str_replace(" ","+",$msg);
$user["step"] = "edit-music-part-4";
$user["editation"]["file-name"] = "$msg-$rand.mp3";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"نام فایل آهنگ شما با موفقیت در سرور ذخیره شد✅
لطفا نام آهنگ (Song Name) رو ارسال کنید :
مثلا :
<b>Song Name</b>",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}else{
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"نام آهنگ فقط باید بصورت متن باشد❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]);
}
}
if($step == "edit-music-part-4" and $msg !== "/cancel"){
if($msg){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$msg = str_replace(" ","+",$msg);
$user["step"] = "edit-music-part-5";
$user["editation"]["song-name"] = "$msg";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"نام آهنگ (Song Name) شما با موفقیت در سرور ذخیره شد✅
لطفا کپشن (Comment) آهنگ رو ارسال کنید :
مثلا :
<b>Comment</b>",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}else{
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"نام آهنگ فقط باید بصورت متن باشد❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]);
}
}
/*
برنامه نویس 
@GoldDev
کپی با ذکر منبع
*/
if($step == "edit-music-part-5" and $msg !== "/cancel"){
if($msg){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$msg = str_replace(" ","+",$msg);
$user["step"] = "edit-music-part-6";
$user["editation"]["comment"] = "$msg";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کپشن آهنگ (Comment) شما با موفقیت در سرور ذخیره شد✅
لطفا تگ خواننده (Music Artist) آهنگ رو ارسال کنید :
مثلا :
<b>Mohsen Yegane</b>",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}else{
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"زیرنویس آهنگ فقط باید بصورت متن باشد❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]);
}
}
if($step == "edit-music-part-6" and $msg !== "/cancel"){
if($msg){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$msg = str_replace(" ","+",$msg);
$user["step"] = "edit-music-part-7";
$user["editation"]["artist"] = "$msg";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تگ خواننده (Music Artist) شما با موفقیت در سرور ذخیره شد✅
لطفا نام آلبوم (Music Album) آهنگ رو ارسال کنید :
مثلا :
<b>Bahar</b>",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}else{
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تگ خواننده آهنگ فقط باید بصورت متن باشد❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]);
}
}
if($step == "edit-music-part-7" and $msg !== "/cancel"){
if($msg){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$msg = str_replace(" ","+",$msg);
$user["step"] = "edit-music-part-8";
$user["editation"]["album"] = "$msg";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"نام آلبوم (Music Album) شما با موفقیت در سرور ذخیره شد✅
لطفا سال تولید آهنگ رو ارسال کنید :
مثلا :
<b>1397</b>",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}else{
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"نام آلبوم آهنگ فقط باید بصورت متن باشد❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]);
}
}
if($step == "edit-music-part-8" and $msg !== "/cancel"){
if($msg and is_numeric($msg)){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$msg = str_replace(" ","+",$msg);
$user["step"] = "edit-music-part-9";
$user["editation"]["saal"] = "$msg";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"سال تولید شما با موفقیت در سرور ذخیره شد✅
لطفا ژانر (genre) آهنگ رو ارسال کنید :
مثلا :
<b>jazz</b>",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
}else{
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تاریخ ساخت آهنگ فقط باید بصورت عدد لاتین باشد❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]);
}
}
if($step == "edit-music-part-9" and $msg !== "/cancel"){
if($msg){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$msg = str_replace(" ","+",$msg);
$user["step"] = "";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
$user_for_music_edit = json_decode(file_get_contents("data/$from_id"),true);
$music_url = $user_for_music_edit["editation"]["url"];
$cover_url = $user_for_music_edit["editation"]["cover"];
$filename = $user_for_music_edit["editation"]["file-name"];
$songname = $user_for_music_edit["editation"]["song-name"];
$comment = $user_for_music_edit["editation"]["comment"];
$artist = $user_for_music_edit["editation"]["artist"];
$album = $user_for_music_edit["editation"]["album"];
$year = $user_for_music_edit["editation"]["saal"];
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تمامی اطلاعات دریافت شد✅
اطلاعات در حال پردازش در سرور ...
این کار ممکن است چند دقیقه طول بکشد❕
صبور باشید و تا اتمام عملیات پیام (دستوری) به ربات ارسال نکنید❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
$json1 = json_decode(file_get_contents("$API_ADDRESS/index.php?music_url=$music_url&cover_url=$cover_url&filename=$filename&songname=$songname&comment=$comment&artist=$artist&album=$album&year=$year&genre=$msg"),true);
$music_edited = $json1['edited_music_url'];
$music_edited_size = $json1['edited_music_size'];
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"فایل موزیک شما با موفقیت ساخته و در سرور ذخیره شد✅
حجم فایل شما : $music_edited_size مگابایت
در حال آپلود در تلگرام ...",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]); 
GoldDev('senddocument',[
'chat_id'=>$chat_id,
'document'=>"$music_edited",
'caption'=>"آهنگ شما با موفقیت ویرایش شد✔️",
]);
file_get_contents("$API_ADDRESS/reset.php");
}else{
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"تاریخ ساخت آهنگ فقط باید بصورت عدد لاتین باشد❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
]);
}
}
if($data == "dl-up"){
GoldDev('deletemessage',[
 'chat_id' => $chatid,
 'message_id' =>$messageid,
]);
$user_data["step"] = "music-dl-part-1";
$outjson = json_encode($user_data,true);
file_put_contents("data/$chatid",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chatid,
 'text'=>"به بخش دانلود و آپلود آهنگ خوشامدید💫
با ارسال لینک مستقیم آهنگ خود میتوانید فایل آن آهنگ را در تلگرام دریافت کنید , همچنین با ارسال آهنگ خود میتوانید لینک دانلود آهنگ را دریافت کنید.",
 'parse_mode'=>"HTML",
]);
}
if($step == "music-dl-part-1"){
if($music){
$filesize = $music_size/1024/1024;
$size = round($filesize,2);
$musictime2 = $music_time / 60;
$musictime = round($musictime2,2);
if($size < 21){
$get = GoldDev('getfile',['file_id'=>$music_id]);
$patch = $get->result->file_path;
 GoldDev('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"در حال دانلود <b>$music_title-$music_artist</b> ...",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
]);
$rand = rand(000,999);
file_put_contents("temp/$music_title-$music_artist-$rand.mp3",file_get_contents('https://api.telegram.org/file/GoldDev'.$Token.'/'.$patch));
 GoldDev('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"<b>$music_title-$music_artist</b>
با موفقیت دانلود شد✅ 
📍حجم موزیک : ($size مگابایت)
📍زمان موزیک : $musictime دقیقه",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✖️دانلود مستقیم✖️", 'url'=>"http://hendoune.telehoster.online/music/temp/$music_title-$music_artist-$rand.mp3"]],
]
])
]);
}else{
 GoldDev('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حجم آهنگ شما باید زیر 20 مگابایت باشد❕",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
]);
}
}
if($msg and $msg !== "/cancel"){
if(strpos($msg,".") !== false and strpos($msg,"mp3") !== false){
$get_file_size = get_file_size($msg);
$filesize = $get_file_size/1024/1024;
$musicsize = round($filesize,2);
if($musicsize < 21){
 GoldDev('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🌀درحال پردازش در سرور ...
✴️حجم فایل $musicsize مگابایت
لطفا صبور باشید و تا زمان اتمام عملیات هیچ دستور (دکمه ای) را در ربات ارسال نکنید❕",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
]);
GoldDev('senddocument',[
'chat_id'=>$chat_id,
'document'=>"$msg",
'caption'=>"فایل مورد نظر با حجم $musicsize مگابایت دانلود و در تلگرام آپلود شد✅",
'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✖️دانلود مستقیم✖️", 'url'=>"$msg"]],
]
])
]);
}else{
 GoldDev('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"حجم آهنگ شما باید زیر 20 مگابایت باشد❕",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
]);
}
}else{
 GoldDev('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"لطفا لینک دانلود یک آهنگ با فرمت mp3 را ارسال کنید❕",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
]);
}
}
}
if($data == "converting"){
GoldDev('deletemessage',[
 'chat_id' => $chatid,
 'message_id' =>$messageid,
]);
$user_data["step"] = "conver-part-1";
$outjson = json_encode($user_data,true);
file_put_contents("data/$chatid",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chatid,
 'text'=>"به بخش تبدیلات خوشامدید🌹
⚜️برای تبدیل آهنگ به وویس لطفا آهنگ خود را ارسال کنید.
⚜️برای تبدیل وویس به آهنگ لطفا وویس خود را ارسال کنید.
⚜️برای تبدیل ویدئو به آهنگ لطفا ویدئو خود را ارسال کنید.",
 'parse_mode'=>"HTML",
]);
}
if($step == "conver-part-1" and $msg !== "/cancel"){
if($voice){
$get = GoldDev('getfile',['file_id'=>$voice_id]);
$patch = $get->result->file_path;
$rand = rand(000,999);
file_put_contents("temp/$rand.mp3",file_get_contents('https://api.telegram.org/file/GoldDev'.$Token.'/'.$patch));
GoldDev('sendaudio',[
'chat_id'=>$chat_id,
'audio'=>new CURLFile("temp/$rand.mp3"),
'caption'=>"وویس شما با موفقیت تبدیل به آهنگ شد✔️",
'reply_to_message_id'=>$message_id,
]);
unlink("temp/$rand.mp3");
}
if($music){
$get = GoldDev('getfile',['file_id'=>$music_id]);
$patch = $get->result->file_path;
$rand = rand(000,999);
file_put_contents("temp/$rand.ogg",file_get_contents('https://api.telegram.org/file/GoldDev'.$Token.'/'.$patch));
GoldDev('sendvoice',[
 'chat_id'=>$chat_id,
 'voice'=>new CURLFile("temp/$rand.ogg"),
 'caption'=>"آهنگ شما با موفقیت تبدیل به وویس شد✔️",
 'reply_to_message_id'=>$message_id,
 ]);
unlink("temp/$rand.wgm");
}
if($video){
$filesize = $video_size/1024/1024;
$video_size1 = round($filesize,2);
if($video_size1 < 21){
$get = GoldDev('getfile',['file_id'=>$video_id]);
$patch = $get->result->file_path;
$rand = rand(000,999);
file_put_contents("temp/$rand.mp3",file_get_contents('https://api.telegram.org/file/GoldDev'.$Token.'/'.$patch));
GoldDev('sendaudio',[
 'chat_id'=>$chat_id,
 'audio'=>new CURLFile("temp/$rand.mp3"),
 'caption'=>"ویدئو شما با موفقیت تبدیل به آهنگ شد✔️",
 'reply_to_message_id'=>$message_id,
 ]);
unlink("temp/$rand.mp3");
}else{
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"حجم ویدئو باید کمتر از 20 مگابایت باشد❕",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"/cancel"]],
],
"resize_keyboard"=>true,
])
]);
}
}
}
if($music and $step == ""){
$rand = rand(0000000000,9999999999);
$user["hash"] = "$rand";
$outjson = json_encode($user,true);
file_put_contents("data/$from_id",$outjson);
$hash_database = json_decode(file_get_contents("hash/$rand"),true);
$hash_database["music_id"] = "$music_id";
$hash_database["caption"] = "$caption";
$hash_database["time"] = "$music_time";
$hash_database["buttons"]["count"] = '';
$outjson0 = json_encode($hash_database,true);
file_put_contents("hash/$rand",$outjson0);
$rand1 = rand(000,999);
GoldDev('senddocument',[
'chat_id'=>$chat_id,
'document'=>"$music_id",
'caption'=>"$caption",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"دکمه لینک دار اضافه کن🔗",'callback_data'=>"add-url-button"]],
[['text'=>"منتشر کن📢",'switch_inline_query'=>"HASH|$rand|$rand1"]],
[['text'=>"🔗ویرایش پیشرفته✂️",'callback_data'=>"edit-pro"],['text'=>"🔗ویرایش ساده✂️",'callback_data'=>"edit-simple"]],
[['text'=>"کپشن رو عوض کن🔅",'callback_data'=>"change-caption"]],
[['text'=>"🔄بخش تبدیلات🔁",'callback_data'=>"converting"],['text'=>"🔗دانلود و آپلود🔗",'callback_data'=>"dl-up"]],
[['text'=>"✂️نمونه گیری و برش (ساخت وویس 🎙)",'callback_data'=>"create-voice"]],
]
])
]);
}
if($data == "create-voice"){
GoldDev('deletemessage',[
 'chat_id' => $chatid,
 'message_id' =>$messageid,
]);
GoldDev('answercallbackquery', [
'callback_query_id' => $update->callback_query->id,
'text' => "در حال پردازش اطلاعات ...",
'show_alert' => false
]);
$user = json_decode(file_get_contents("data/$chatid"),true);
$hash = $user['hash'];
$hash_database = json_decode(file_get_contents("hash/$hash"),true);
$music_time1 = $hash_database["time"];
$user = json_decode(file_get_contents("data/$chatid"),true);
$user["step"] = "create-voice-1";
$outjson = json_encode($user,true);
file_put_contents("data/$chatid",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chatid,
 'text'=>"دوست عزیز موزیک شما دارای <b>$music_time1</b> ثانیه است❕
اگر شما قصد برش و ساخت دموی موزیک رو دارید لطفا ثانیه شروع برش رو ارسال کنید✂️
مثلا از 0 ثانیه ببر !
برای لغو عملیات از دستور /cancel استفاده کنید✔️",
 'parse_mode'=>"html",
]);
}
if($step == "create-voice-1" and $msg !== "/cancel"){
$hash_database = json_decode(file_get_contents("hash/$hash"),true);
$music_time1 = $hash_database["time"];
if($msg < 0 or $msg > $music_time1){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"دقت کنید که کل موزیک شما دارای $music_time1 ثانیه است❕
لذا برای برش باید عددی بیشتر از 0 و کمتر از $music_time1 ارسال کنید❕",
 'parse_mode'=>"html",
]);
}else{
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$user["step"] = "create-voice-2";
$user["boresh1"] = "$msg";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"دوست عزیز موزیک شما دارای <b>$music_time1</b> ثانیه است❕
من از ثانیه $msg برش میدهم!
از $msg تا چند ثانیه برش دهم؟
یک عدد ارسال کن بطور مثال بگو تا $music_time1 آنوقت من از ثانیه $msg شروع میکنم و $music_time1 ثانیه بعدش را برش میدهم😅",
 'parse_mode'=>"html",
]);
}
}
if($step == "create-voice-2" and $msg !== "/cancel"){
$hash_database = json_decode(file_get_contents("hash/$hash"),true);
$music_time1 = $hash_database["time"];
if($msg < 0 or $msg > $music_time1){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"دقت کنید که کل موزیک شما دارای $music_time1 ثانیه است❕
لذا برای برش باید عددی بیشتر از 0 و کمتر از $music_time1 ارسال کنید❕",
 'parse_mode'=>"html",
]);
}else{
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$music_id1 = $hash_database["music_id"];
$boresh1 = $user['boresh1'];
$boresh2 = $msg;
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"بسیار خب!
درحال ساخت نمونه ویس از آهنگ شما ...❕
لطفا کمی صبر کنید⚜️
آهنگ شما دارای $music_time1 ثانیه است و از ثانیه $boresh1 تا $boresh2 ثانیه بعد از آن برش میخورد✂️",
 'parse_mode'=>"html",
]);
$get = GoldDev('getfile',['file_id'=>$music_id1]);
$patch = $get->result->file_path;
$rand = rand(00000000,99999999);
file_put_contents("cut-merge/$rand.WGM",file_get_contents('https://api.telegram.org/file/GoldDev'.$Token.'/'.$patch));
$link = file_get_contents("http://hendoune.telehoster.online/music/cut-merge/index.php?type=cut&rand=$rand&first_time=$boresh1&last_time=$boresh2");
GoldDev('sendvoice',[
 'chat_id'=>$chat_id,
 'voice'=>new CURLFile("cut-merge/$rand-1.WGM"),
 'caption'=>"نمونه گیری با موفقیت انجام شد✔️",
'reply_to_message_id'=>$message_id,
 ]);
$hash_database = json_decode(file_get_contents("hash/$hash"),true);
$music_id = $hash_database["music_id"];
$caption = $hash_database["caption"];
$buttons = $hash_database["buttons"]["count"];
if($buttons == ''){
$newbuttons = 0;
}
if($buttons !== ''){
settype($buttons,"integer");
$newbuttons = $buttons + 1;
}
$hash_database["buttons"]["$newbuttons"]["url"] = "$msg";
$hash_database["buttons"]["count"] = "$newbuttons";
$outjson = json_encode($hash_database,true);
file_put_contents("hash/$hash",$outjson);
$user["step"] = "";
$outjson0 = json_encode($user,true);
file_put_contents("data/$chat_id",$outjson0);
$hash_database = json_decode(file_get_contents("hash/$hash"),true);
$music_id = $hash_database["music_id"];
$caption = $hash_database["caption"];
$buttons = $hash_database["buttons"]["count"];
if($buttons >= 0){
for ($i=0; $i <= $buttons; $i++){
$name=$hash_database["buttons"]["$i"]['name'];
$url=$hash_database["buttons"]["$i"]['url'];
$d4[] = [['text'=>"$name",'url'=>"$url"]];
}
}
$rand1 = rand(000,999);
$d4[] = [['text'=>"دکمه لینک دار اضافه کن🔗",'callback_data'=>"add-url-button"]];
$d4[] = [['text'=>"منتشر کن📢",'switch_inline_query'=>"HASH|$rand|$rand1"]];
$d4[] = [['text'=>"🔗ویرایش پیشرفته✂️",'callback_data'=>"edit-pro"],['text'=>"🔗ویرایش ساده✂️",'callback_data'=>"edit-simple"]];
$d4[] = [['text'=>"کپشن رو عوض کن🔅",'callback_data'=>"change-caption"]];
$d4[] = [['text'=>"🔄بخش تبدیلات🔁",'callback_data'=>"converting"],['text'=>"🔗دانلود و آپلود🔗",'callback_data'=>"dl-up"]];
$d4[] = [['text'=>"✂️نمونه گیری و برش (ساخت وویس 🎙)",'callback_data'=>"create-voice"]];
GoldDev('senddocument',[
'chat_id'=>$chat_id,
'document'=>"$music_id",
'caption'=>"$caption",
'parse_mode'=>"HTML",
  'reply_markup'=>json_encode([
'inline_keyboard'=>$d4
])
]);
$user["step"] = "";
$user["boresh1"] = "";
$outjson = json_encode($user,true);
file_put_contents("data/$chat_id",$outjson);
unlink("cut-merge/$rand.WGM");
unlink("cut-merge/$rand-1.WGM");
}
}
if($data == "add-url-button"){
GoldDev('deletemessage',[
 'chat_id' => $chatid,
 'message_id' =>$messageid,
]);
$user = json_decode(file_get_contents("data/$chatid"),true);
$user["step"] = "add-url-1";
$outjson = json_encode($user,true);
file_put_contents("data/$chatid",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chatid,
 'text'=>"جهت اضافه کردن دکمه لینک دار به آهنگ خود ابتدا نام دکمه را ارسال کنید یا برای لغو عملیات دستور /cancel را ارسال کنید :",
 'parse_mode'=>"html",
]);
}
if($msg !== "/cancel" and $step == "add-url-1"){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$hash_database = json_decode(file_get_contents("hash/$hash"),true);
$music_id = $hash_database["music_id"];
$caption = $hash_database["caption"];
$buttons = $hash_database["buttons"]["count"];
if($buttons == ''){
$newbuttons = 0;
}
if($buttons !== ''){
settype($buttons,"integer");
$newbuttons = $buttons + 1;
}
$hash_database["buttons"]["$newbuttons"]["name"] = "$msg";
$outjson = json_encode($hash_database,true);
file_put_contents("hash/$hash",$outjson);
$user["step"] = "add-url-button-2";
$outjson0 = json_encode($user,true);
file_put_contents("data/$chat_id",$outjson0);
GoldDev('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"اکنون لینک خود را ارسال نمیایید📍
ابتدای لینک باید حاوی 
http یا https
باشد✔️
مثال :
https://Google.com",
 'parse_mode'=>"html",
  'reply_to_message_id'=>$message_id,
]);
}
if($msg !== "/cancel" and $step == "add-url-button-2"){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$hash_database = json_decode(file_get_contents("hash/$hash"),true);
$music_id = $hash_database["music_id"];
$caption = $hash_database["caption"];
$buttons = $hash_database["buttons"]["count"];
if($buttons == ''){
$newbuttons = 0;
}
if($buttons !== ''){
settype($buttons,"integer");
$newbuttons = $buttons + 1;
}
$hash_database["buttons"]["$newbuttons"]["url"] = "$msg";
$hash_database["buttons"]["count"] = "$newbuttons";
$outjson = json_encode($hash_database,true);
file_put_contents("hash/$hash",$outjson);
$user["step"] = "";
$outjson0 = json_encode($user,true);
file_put_contents("data/$chat_id",$outjson0);
$hash_database = json_decode(file_get_contents("hash/$hash"),true);
$music_id = $hash_database["music_id"];
$caption = $hash_database["caption"];
$buttons = $hash_database["buttons"]["count"];
if($buttons >= 0){
for ($i=0; $i <= $buttons; $i++){
$name=$hash_database["buttons"]["$i"]['name'];
$url=$hash_database["buttons"]["$i"]['url'];
$d4[] = [['text'=>"$name",'url'=>"$url"]];
}
}
$rand = rand(000,999);
$d4[] = [['text'=>"دکمه لینک دار اضافه کن🔗",'callback_data'=>"add-url-button"]];
$d4[] = [['text'=>"منتشر کن📢",'switch_inline_query'=>"HASH|$hash|$rand"]];
$d4[] = [['text'=>"🔗ویرایش پیشرفته✂️",'callback_data'=>"edit-pro"],['text'=>"🔗ویرایش ساده✂️",'callback_data'=>"edit-simple"]];
$d4[] = [['text'=>"کپشن رو عوض کن🔅",'callback_data'=>"change-caption"]];
$d4[] = [['text'=>"🔄بخش تبدیلات🔁",'callback_data'=>"converting"],['text'=>"🔗دانلود و آپلود🔗",'callback_data'=>"dl-up"]];
$d4[] = [['text'=>"✂️نمونه گیری و برش (ساخت وویس 🎙)",'callback_data'=>"create-voice"]];
GoldDev('senddocument',[
'chat_id'=>$chat_id,
'document'=>"$music_id",
'caption'=>"$caption",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'inline_keyboard'=>$d4
])
]);
}
if($data == "change-caption"){
GoldDev('deletemessage',[
 'chat_id' => $chatid,
 'message_id' =>$messageid,
]);
$user = json_decode(file_get_contents("data/$chatid"),true);
$user["step"] = "change-caption-1";
$outjson = json_encode($user,true);
file_put_contents("data/$chatid",$outjson);
GoldDev('sendMessage',[
 'chat_id'=>$chatid,
 'text'=>"جهت تغییر کپشن آهنگ یک متن برای کپشن جدید ارسال کنید.
از دستورات زیر میتوانید در متن خود استفاده کنید :
برای ضخیم کردن متن :
<b>TEXT</b>
برای کج کردن متن :
<i>TEXT</i>
برای کد کردن متن :
<code>TEXT</code>
برای لینک دار کردن متن :
<a href ='URL'>TEXT</a>
اکنون کپشن خود را ارسال کنید یا برای لغو عملیات دستور /cancel را ارسال کنید :",
 'parse_mode'=>"MarkDown",
]);
}
if($msg !== "/cancel" and $step == "change-caption-1"){
$user = json_decode(file_get_contents("data/$from_id"),true);
$last_msg = $user["last_msg"];
GoldDev('deletemessage',[
 'chat_id' => $chat_id,
 'message_id' =>$last_msg,
]);
$hash_database = json_decode(file_get_contents("hash/$hash"),true);
$music_id = $hash_database["music_id"];
$buttons = $hash_database["buttons"]["count"];
$hash_database["caption"] = "$msg";
$outjson = json_encode($hash_database,true);
file_put_contents("hash/$hash",$outjson);
$user["step"] = "";
$outjson0 = json_encode($user,true);
file_put_contents("data/$chat_id",$outjson0);
if($buttons == ''){
$buttons = -1;
}
if($buttons >= 0){
for ($i=0; $i <= $buttons; $i++){
$name=$hash_database["buttons"]["$i"]['name'];
$url=$hash_database["buttons"]["$i"]['url'];
$d4[] = [['text'=>"$name",'url'=>"$url"]];
}
}
$rand = rand(000,999);
$d4[] = [['text'=>"دکمه لینک دار اضافه کن🔗",'callback_data'=>"add-url-button"]];
$d4[] = [['text'=>"منتشر کن📢",'switch_inline_query'=>"HASH|$hash|$rand"]];
$d4[] = [['text'=>"🔗ویرایش پیشرفته✂️",'callback_data'=>"edit-pro"],['text'=>"🔗ویرایش ساده✂️",'callback_data'=>"edit-simple"]];
$d4[] = [['text'=>"کپشن رو عوض کن🔅",'callback_data'=>"change-caption"]];
$d4[] = [['text'=>"🔄بخش تبدیلات🔁",'callback_data'=>"converting"],['text'=>"🔗دانلود و آپلود🔗",'callback_data'=>"dl-up"]];
$d4[] = [['text'=>"✂️نمونه گیری و برش (ساخت وویس 🎙)",'callback_data'=>"create-voice"]];
GoldDev('senddocument',[
'chat_id'=>$chat_id,
'document'=>"$music_id",
'caption'=>"$msg",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'inline_keyboard'=>$d4
])
]);
}
if($msg == "/cancel"){
$user["step"] = "";
$outjson0 = json_encode($user,true);
file_put_contents("data/$chat_id",$outjson0);
$hash_database = json_decode(file_get_contents("hash/$hash"),true);
$music_id = $hash_database["music_id"];
$caption = $hash_database["caption"];
$buttons = $hash_database["buttons"]["count"];
if($buttons == ''){
$buttons = -1;
}
if($buttons >= 0){
for ($i=0; $i <= $buttons; $i++){
$name=$hash_database["buttons"]["$i"]['name'];
$url=$hash_database["buttons"]["$i"]['url'];
$d4[] = [['text'=>"$name",'url'=>"$url"]];
}
}
$rand = rand(000,999);
$d4[] = [['text'=>"دکمه لینک دار اضافه کن🔗",'callback_data'=>"add-url-button"]];
$d4[] = [['text'=>"منتشر کن📢",'switch_inline_query'=>"HASH|$rand|$rand1"]];
$d4[] = [['text'=>"🔗ویرایش پیشرفته✂️",'callback_data'=>"edit-pro"],['text'=>"🔗ویرایش ساده✂️",'callback_data'=>"edit-simple"]];
$d4[] = [['text'=>"کپشن رو عوض کن🔅",'callback_data'=>"change-caption"]];
$d4[] = [['text'=>"🔄بخش تبدیلات🔁",'callback_data'=>"converting"],['text'=>"🔗دانلود و آپلود🔗",'callback_data'=>"dl-up"]];
$d4[] = [['text'=>"✂️نمونه گیری و برش (ساخت وویس 🎙)",'callback_data'=>"create-voice"]];
GoldDev('senddocument',[
'chat_id'=>$chat_id,
'document'=>"$music_id",
'caption'=>"$caption",
'parse_mode'=>"HTML",
'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
'inline_keyboard'=>$d4
])
]);
}
if($inline){
$load = trim(str_replace("HASH ","",$inline));
$load = explode("|",$load."|||||");
$HASH = trim($load[1]);
$hash_database = json_decode(file_get_contents("hash/$HASH"),true);
$music_id = $hash_database["music_id"];
$caption = $hash_database["caption"];
$buttons = $hash_database["buttons"]["count"];
if($buttons == ''){
$buttons = -1;
}
if($buttons >= 0){
for ($i=0; $i <= $buttons; $i++){
$name=$hash_database["buttons"]["$i"]['name'];
$url=$hash_database["buttons"]["$i"]['url'];
$d4[] = [['text'=>"$name",'url'=>"$url"]];
}
}
$d4[] = [['text'=>"منتشر کن📢",'switch_inline_query'=>"$inline"]];
GoldDev('answerInlineQuery', [
'inline_query_id' => $update->inline_query->id,
'results' => json_encode([[
'type' => 'audio',
'id' => base64_encode(rand(5,555)),
'audio_file_id'=>"$music_id",
'caption' => "$caption",
'parse_mode' => "HTML",
  'reply_markup'=>([
'inline_keyboard'=>$d4
])
]])
]);
}
    
    
    
