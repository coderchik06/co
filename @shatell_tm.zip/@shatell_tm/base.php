<?php
/*
برنامه نویس 
@GoldDev
کپی با ذکر منبع
*/
ob_start();
$Token = 'Put Token';
define('API_KEY',$Token);
ini_set("log_errors","off");
date_default_timezone_set('Asia/Tehran');
//-------
function GoldDev($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$msg = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$music = $message->audio;
$music_id = $music->file_id;
$music_title = $music->title;
$music_artist = $music->performer;
$music_time = $music->duration;
$music_size = $music->file_size;
$photo = $message->photo;
$voice = $message->voice;
$voice_id = $voice->file_id;
$video = $message->video;
$video_id = $video->file_id;
$video_size = $video->file_size;
$caption = $message->caption;
$inline = $update->inline_query->query;
$inline_from_id= $update->inline_query->from->id;
$data = $update->callback_query->data;
$chatid = $update->callback_query->message->chat->id;
$messageid = $update->callback_query->message->message_id;
$Bot_Id = "AudioEditRobot"; // Bot Id
$Sudo = 123456789; // admin id
$API_ADDRESS = 'https://golddev/api'; // آدرس پوشه api
$user = json_decode(file_get_contents("data/$from_id"),true);
$step = $user["step"];
$last_msg = $user["last_msg"];
$hash = $user["hash"];
$user_data = json_decode(file_get_contents("data/$chatid"),true);
$step_data = $user_data["step"];
$hash_data = $user_data["hash"];
$gettime = json_decode(file_get_contents("http://api.bot-dev.org/time/"),true);
$time1 = $gettime["ENtime"];
$date_fa = $gettime["FAdate"];
//------
function save($filename, $data)
{
$file = fopen($filename, 'w');
fwrite($file, $data);
fclose($file);
}
function get_file_size($url) {      
    $file = $url;
 
    $ch = curl_init($file);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
 
    $data = curl_exec($ch);
    curl_close($ch);
 
    if (preg_match('/Content-Length: (\d+)/', $data, $matches)) {
    	
        // Contains file size in bytes
        $fileSize = (int)$matches[1];
 
        return $fileSize;
    }
}


