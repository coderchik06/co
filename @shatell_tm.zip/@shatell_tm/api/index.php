<?php
function friendly_size($size,$round=2){
$sizes=array(' Byts',' Kb',' Mb',' Gb',' Tb');
$total=count($sizes)-1;
for($i=0;$size>1024 && $i<$total;$i++){
$size/=1024;
}
return round($size,$round).$sizes[$i];
}
$domain = "http://hendoune.telehoster.online/music/api/Music/";
$default_mp3_directory =  "./Music/";
$mp3_filepath = $_GET['music_url'];
$mp3_filename = $_GET['filename'];
$mp3_songname = $_GET['songname'];
$mp3_comment = $_GET['comment'];
$mp3_artist = $_GET['artist'];
$mp3_album = $_GET['album'];
$mp3_year = $_GET['year'];
$mp3_genre = $_GET['genre'];
$mp3_cover = $_GET['cover_url'];
if($mp3_filename!=""){
$mp3_filename = str_replace(DIRECTORY_SEPARATOR,"-X-",$mp3_filename);
if(strtolower(end(explode(".",basename($mp3_filepath))))!="mp3"){
exit("<p>آدرس بایل با فرمت MP3 باشد.</p>");
}
if(strtolower(end(explode(".",basename($mp3_filename))))!="mp3"){
exit("<p>نام فایل باید پسوند MP3 داشته باشد.</p>");
}
$sname = $default_mp3_directory.$mp3_filename;
if(copy($mp3_filepath,$sname)){
$size = friendly_size(filesize($sname));
$output = array("your_music_url"=>$mp3_filepath,"edited_music_url"=>"$domain$mp3_filename","edited_music_size"=>$size);
header('Content-Type: application/json');
$outjson = json_encode($output);
echo $outjson;
$mp3_tagformat = 'UTF-8';
require_once('getid3/getid3.php');
$mp3_handler = new getID3;
$mp3_handler->setOption(array('encoding'=>$mp3_tagformat));
require_once('getid3/write.php');
$mp3_writter = new getid3_writetags;
$mp3_writter->filename       = $sname;
$mp3_writter->tagformats     = array('id3v1', 'id3v2.3');
$mp3_writter->overwrite_tags = true;
$mp3_writter->tag_encoding   = $mp3_tagformat;
$mp3_writter->remove_other_tags = true;
$mp3_data['title'][]   = $mp3_songname;
$mp3_data['artist'][]  = $mp3_artist;
$mp3_data['album'][]   = $mp3_album;
$mp3_data['year'][]    = $mp3_year;
$mp3_data['genre'][]   = $mp3_genre;
$mp3_data['comment'][] = $mp3_comment;
if($mp3_cover !== null){
$rand = rand(00000,99999);
file_put_contents("Music/$rand.png",file_get_contents("$mp3_cover"));
$mp3_data['attached_picture'][0]['data'] = file_get_contents("Music/$rand.png");
$mp3_data['attached_picture'][0]['picturetypeid'] = 3;
$mp3_data['attached_picture'][0]['description'] = "Music Cover";
$mp3_data['attached_picture'][0]['mime'] = "image/png";
}
$mp3_writter->tag_data = $mp3_data;
if($mp3_writter->WriteTags()) {
}
else{
echo"<p>Failed to write tags!<br>".implode("<br /><br /></p>",$mp3_writter->errors);
}
}
else{echo"<p>امکان کپی فایل مقدور نیست.</p>";}
}
else{echo"<p>نام فایل خالی است.</p>";}
