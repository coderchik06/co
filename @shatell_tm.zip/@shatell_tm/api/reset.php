<?php
function deletefolder($path) { 
if ($handle=opendir($path)) { 
while (false!==($file=readdir($handle))) { 
if ($file<>"." AND $file<>"..") { 
if (is_file($path.'/'.$file))  { 
@unlink($path.'/'.$file); 
} 
if (is_dir($path.'/'.$file)) { 
deletefolder($path.'/'.$file); 
@rmdir($path.'/'.$file); 
} 
} 
} 
} 
}
deletefolder("Music/");
file_put_contents("Music/index.html","404");