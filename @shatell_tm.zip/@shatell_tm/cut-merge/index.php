<?php
ini_set("log_errors","off");
include 'base.php';
$domain = "http://hendoune.telehoster.online/music/cut-merge";
$first_time = $_GET['first_time'];
$last_time = $_GET['last_time'];
$rand = $_GET['rand'];
$type = $_GET['type'];
if($type == "cut"){
if( $first_time !== null and $last_time !== null and $rand !== null){
$path = "$rand.WGM";
$mp3 = new PHPMP3($path);
$mp3_1 = $mp3->extract($first_time,$last_time);
$mp3_1->save("$rand-1.WGM");
echo "$domain/$rand-1.WGM";
}else{
echo "false";
}
}